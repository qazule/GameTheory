def prefsCurToNew(wpref_matrix, new_m, cur_m, N):

    for i in range(N):
        if (wpref_matrix.index(cur_m) < wpref_matrix.index(new_m)):
            return True
        else:
            return False


def stableMarriage(pref_matrix, N, boy_optimal=True):
    adds = 0
    new_matrix = []
    first = "Woman"
    second = "Man"
    if not boy_optimal:
        first = "Man"
        second = "Woman"
        for i in range(2*N):
            if i < N:
                adds = -N
            else:
                adds = N
            for j in range(N):
                pref_matrix[i][j] += adds
        for i in range(N):
            new_matrix.append(pref_matrix[N+i])
        for i in range(N):
            new_matrix.append(pref_matrix[i])
        pref_matrix = new_matrix

    #  All men are available = (Flase)
    menFree = [False for i in range(N)]
    #  if partner value equals -1  -> woman is free
    womans_partner = [-1 for i in range(N)]

    free_men = N

    while (free_men > 0):

        # Pick the first free man
        m = 0
        while (m < N):
            if (menFree[m] is False):
                break
            m += 1
        # go to all women one by one in pref_matrix of m
        i = 0
        while i < N and menFree[m] is False:
            w = pref_matrix[m][i]

            if (womans_partner[w - N] == -1):
                womans_partner[w - N] = m
                menFree[m] = True
                free_men -= 1
            else:
                cur_m = womans_partner[w - N]
                if (prefsCurToNew(pref_matrix[w], m, cur_m, N) is False):
                    womans_partner[w - N] = m
                    menFree[m] = True
                    menFree[cur_m] = False
            i += 1

    print(first, "\t", second)
    for i in range(N):
        print(i, "\t", womans_partner[i])


pref_matrix = [[6, 4, 5, 7], [7, 6, 5, 4],
               [7, 4, 6, 5], [4, 5, 6, 7],
               [1, 2, 0, 3], [0, 2, 3, 1],
               [3, 0, 1, 2], [1, 2, 3, 0]]


stableMarriage(pref_matrix, 4, boy_optimal=False)
