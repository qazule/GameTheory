def generate_graph(pref_matrix, remaining_person):
    graph = dict()
    for r in remaining_person:
        for p in pref_matrix[r]:
            if p in remaining_person:
                graph[r] = p
                break
    return graph


def find_cycle(graph: dict):
    itterated_path = []
    start_node = list(graph.keys())[0]

    itterated_path.append(start_node)
    next_node = None
    while True:
        next_node = graph[start_node]
        if next_node in itterated_path:
            break

        itterated_path.append(next_node)
        start_node = next_node

    print(itterated_path)
    cycle_node = next_node
    cycle = dict()

    while itterated_path:
        cycle[itterated_path[-1]] = cycle_node
        if itterated_path[-1] == cycle_node:
            break
        cycle_node = itterated_path[-1]
        itterated_path.pop()

    print(cycle)
    return cycle


def trading_cycle(pref_matrix):
    # indexing numbers
    for i in range(len(pref_matrix)):
        for j in range(len(pref_matrix[i])):
            pref_matrix[i][j] -= 1

    remaining_person = [i for i in range(len(pref_matrix))]
    result = dict()
    # while loop of remaining persons
    while remaining_person:
        # create graph
        graph = generate_graph(pref_matrix, remaining_person)
        # find cycles
        cycle = find_cycle(graph)
        # add new assosiationa and delete cycle node from awaiting graph
        result.update(cycle)
        for node in cycle:
            if node in remaining_person:
                remaining_person.remove(node)
    return {key+1: value+1 for key, value in result.items()}


pref_matrix = [[2, 3, 1, 4, 5, 6, 7],
               [3, 2, 5, 7, 6, 1, 4],
               [6, 4, 1, 2, 3, 5, 7],
               [3, 7, 2, 4, 3, 6, 5],
               [6, 3, 1, 2, 7, 4, 5],
               [7, 5, 6, 1, 3, 2, 4],
               [5, 4, 2, 7, 6, 3, 1]]

result = trading_cycle(pref_matrix)

print("person\tRoom")
for key, value in result.items():
    print(f"{key}\t{value}")
